package com.ngts.wappelyzerweb

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import com.google.android.material.button.MaterialButton

class ForthActivity : AppCompatActivity() {

    private lateinit var mButton : MaterialButton
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_forth)

        mButton = findViewById(R.id.confirm_password)
        mButton.setOnClickListener(View.OnClickListener { // starting background task to update product
            val fp = Intent(applicationContext,FiveActivity::class.java)
            startActivity(fp)
        })
    }
}
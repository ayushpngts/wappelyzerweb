package com.ngts.wappelyzerweb


import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton


class SecondActivity : AppCompatActivity() {

    private lateinit var mButton : MaterialButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_second)

        mButton = findViewById(R.id.singupbtn)
        mButton.setOnClickListener(View.OnClickListener { // starting background task to update product
            val fp = Intent(applicationContext,ThirdActivity::class.java)
            startActivity(fp)
        })
    }
}
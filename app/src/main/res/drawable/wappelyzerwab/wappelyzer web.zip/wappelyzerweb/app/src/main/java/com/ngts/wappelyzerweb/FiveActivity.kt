package com.ngts.wappelyzerweb

import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import com.google.android.material.button.MaterialButton

class FiveActivity : AppCompatActivity() {

    private lateinit var mButton : MaterialButton

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_five)

        mButton = findViewById(R.id.button_Continue)
        mButton.setOnClickListener(View.OnClickListener { // starting background task to update product
            val fp = Intent(applicationContext,SixActivity::class.java)
            startActivity(fp)
        })
    }
}
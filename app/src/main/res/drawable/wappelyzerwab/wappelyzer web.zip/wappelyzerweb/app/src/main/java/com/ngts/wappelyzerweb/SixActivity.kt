package com.ngts.wappelyzerweb

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import com.google.android.material.button.MaterialButton

class SixActivity : AppCompatActivity() {
    private lateinit var mButton : MaterialButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_six)

        mButton = findViewById(R.id.btnSingup1)
        mButton.setOnClickListener(View.OnClickListener { // starting background task to update product

        })

    }
}